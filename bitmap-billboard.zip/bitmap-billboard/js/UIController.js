class UIController {
    constructor(container) {
        this.debug = document.getElementById('debug');
        this.container = container || document.body;
        this.hoverLabel = null;
        this.modalOverlay = document.getElementById('modal-overlay');
        if (this.modalOverlay) {
            this.modalBody = document.getElementById('modal-body');
            this.closeBtn = this.modalOverlay.querySelector('.close-btn');
        }
        this.searchInput = document.getElementById('search-input');
        this.searchBtn = document.getElementById('search-btn');
        this._setupEventListeners();
    }

    _setupEventListeners() {
        if (this.closeBtn) this.closeBtn.addEventListener('click', () => this.hideModal());
        if (this.modalOverlay) this.modalOverlay.addEventListener('click', (e) => { if (e.target === this.modalOverlay) this.hideModal(); });
    }

    log(msg) {
        if (!this.debug) return;
        const lines = this.debug.innerHTML.split('<br>').filter(line => line.trim() !== '');
        while (lines.length >= 10) lines.shift();
        lines.push(msg);
        this.debug.innerHTML = lines.join('<br>');
        console.log(msg);
    }

    showHoverLabel(text, event) {
        this.hideHoverLabel();
        this.hoverLabel = document.createElement('div');
        this.hoverLabel.className = 'label';
        this.hoverLabel.textContent = text;
        this.container.appendChild(this.hoverLabel);
        const rect = this.container.getBoundingClientRect();
        this.hoverLabel.style.left = `${event.clientX - rect.left}px`;
        this.hoverLabel.style.top = `${event.clientY - rect.top}px`;
    }

    hideHoverLabel() {
        if (this.hoverLabel) this.hoverLabel.remove();
        this.hoverLabel = null;
    }
    
    showModal(contentUrl, width = 0, height = 0) {
        if (!this.modalOverlay || !contentUrl) return;

        this.modalBody.innerHTML = '';

        const isTwitterLink = contentUrl.includes('twitter.com') || contentUrl.includes('x.com');

        if (isTwitterLink) {
            // --- Twitter/X Link Handler ---
            const linkTypeText = contentUrl.includes('/status/') ? 'X Status' : 'X Profile';
            const html = `
                <div style="width: 100%; height: 100%; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; color: #e0e0e0; padding: 20px; box-sizing: border-box;">
                    <h3 style="margin: 0 0 10px 0; font-size: 1.2em; font-weight: 500;">External Link</h3>
                    <p style="margin: 0 0 25px 0; color: #999; font-size: 0.9em;">This content will open in a new tab.</p>
                    <a href="${contentUrl}" target="_blank" rel="noopener noreferrer" style="display: inline-block; padding: 12px 28px; background-color: #1DA1F2; color: #ffffff; text-decoration: none; border-radius: 99px; font-weight: bold; transition: background-color 0.2s ease;">
                        Open ${linkTypeText}
                    </a>
                </div>
            `;
            this.modalBody.innerHTML = html;

        } else {
            // --- Normal Link Handler ---
            const html = `
                <div style="width: 100%; height: 100%; display: flex; flex-direction: column;">
                    <div style="padding: 0 0 15px 0; text-align: right; border-bottom: 1px solid #444; margin-bottom: 15px;">
                        <a href="${contentUrl}" target="_blank" rel="noopener noreferrer" style="color: #aaa; font-size: 13px; text-decoration: none;">
                            Open in a new window ↗
                        </a>
                    </div>
                    <iframe src="${contentUrl}" style="width: 100%; flex-grow: 1; border: none;"></iframe>
                </div>
            `;
            this.modalBody.innerHTML = html;
        }

        this.modalOverlay.classList.add('active');
    }

    hideModal() {
        if (!this.modalOverlay) return;
        this.modalOverlay.classList.remove('active');
        this.modalBody.innerHTML = '';
    }

    onSearch(callback) {
        if (!this.searchBtn || !this.searchInput) return;
        const performSearch = () => {
            const query = this.searchInput.value.trim();
            if (query) callback(query);
        };
        this.searchBtn.addEventListener('click', performSearch);
        this.searchInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') performSearch(); });
    }
}