class MapController {
    constructor(scene) {
        this.scene = scene;
        this.parcelSize = 20;
        this.gap = 0;
        this.parcelsPerRow = 1000;
        this.totalParcels = 1000000;
        this.instancedMesh = null;
        this.highlightFrame = this._createHighlightFrame();
        this.avatarGroup = new THREE.Group();
        this.textureLoader = new THREE.TextureLoader();

        // 【Lazy Load】用于跟踪已加载的头像，防止重复渲染
        this.loadedAvatarIds = new Set();
    }

    create() {
        this._createParcels();
        this.scene.add(this.highlightFrame);
        this.scene.add(this.avatarGroup);
    }

    _createParcels() {
        const geometry = new THREE.PlaneGeometry(this.parcelSize, this.parcelSize);
        const vertexShader = `varying float vInstanceId; void main() { vInstanceId = float(gl_InstanceID); gl_Position = projectionMatrix * modelViewMatrix * instanceMatrix * vec4(position, 1.0); }`;
        const fragmentShader = `varying float vInstanceId; vec3 hsl2rgb(vec3 c) { vec3 rgb = clamp(abs(mod(c.x*6.0+vec3(0.0,4.0,2.0),6.0)-3.0)-1.0, 0.0, 1.0); return c.z + c.y * (rgb-0.5)*(1.0-abs(2.0*c.z-1.0)); } float random(float n) { return fract(sin(n) * 43758.5453123); } void main() { float lightness = 0.55 + random(vInstanceId) * 0.2; vec3 hslColor = vec3(0.33, 0.5, lightness); gl_FragColor = vec4(hsl2rgb(hslColor), 1.0); }`;
        const material = new THREE.ShaderMaterial({ vertexShader, fragmentShader });
        this.instancedMesh = new THREE.InstancedMesh(geometry, material, this.totalParcels);
        const dummy = new THREE.Object3D();
        for (let i = 0; i < this.totalParcels; i++) {
            const pos = this.getParcelPosition(i);
            dummy.position.set(pos.x, pos.y, 0);
            dummy.updateMatrix();
            this.instancedMesh.setMatrixAt(i, dummy.matrix);
        }
        this.scene.add(this.instancedMesh);
    }

    /**
     * 【Lazy Load】此函数现在用于处理增量加载的数据
     */
    loadAvatars(configs) {
        if (!configs || configs.length === 0) return;
        configs.forEach(config => {
            const bitmapId = parseInt(config.bitmap_id, 10);
            if (!this.loadedAvatarIds.has(bitmapId)) {
                this.createDynamicAvatar(
                    bitmapId - 1, config.image_url, config.iframe_url,
                    config.iframe_width, config.iframe_height
                );
                this.loadedAvatarIds.add(bitmapId);
            }
        });
    }
    
    // 基于您的原始代码，保留了isGif标志
    createDynamicAvatar(bitmapIndex, imageUrl, iframeUrl = null, iframeWidth = 0, iframeHeight = 0) {
        if (this.avatarGroup.children.find(avatar => avatar.userData.bitmapIndex === bitmapIndex)) return;
        const avatarGeometry = new THREE.PlaneGeometry(this.parcelSize, this.parcelSize);
        const texture = this.textureLoader.load(imageUrl, () => {}, undefined, (err) => { console.error('Error loading texture.', err); });
        texture.colorSpace = THREE.SRGBColorSpace;
        const material = new THREE.MeshBasicMaterial({ map: texture, transparent: true });
        const avatarMesh = new THREE.Mesh(avatarGeometry, material);
        const pos = this.getParcelPosition(bitmapIndex);
        avatarMesh.position.set(pos.x, pos.y, 0.05);
        avatarMesh.userData = {
            isAvatar: true,
            bitmapIndex: bitmapIndex,
            bitmapId: `${bitmapIndex + 1}.bitmap`,
            contentUrl: iframeUrl,
            iframeWidth: parseInt(iframeWidth, 10) || 0,
            iframeHeight: parseInt(iframeHeight, 10) || 0,
            isGif: imageUrl.toLowerCase().endsWith('.gif')
        };
        this.avatarGroup.add(avatarMesh);
    }

    _createHighlightFrame() {
        const frameGeometry = new THREE.EdgesGeometry(new THREE.PlaneGeometry(this.parcelSize, this.parcelSize));
        const frameMaterial = new THREE.LineBasicMaterial({ color: 0xffff00, linewidth: 10 });
        const frame = new THREE.LineSegments(frameGeometry, frameMaterial);
        frame.position.z = 0.1;
        frame.visible = false;
        return frame;
    }
    
    getParcelPosition(index) {
        const row = Math.floor(index / this.parcelsPerRow);
        const col = index % this.parcelsPerRow;
        const x = col * (this.parcelSize + this.gap) - ((this.parcelsPerRow - 1) * (this.parcelSize + this.gap) / 2);
        const y = -row * (this.parcelSize + this.gap) + (((this.totalParcels / this.parcelsPerRow) - 1) * (this.parcelSize + this.gap) / 2);
        return { x, y };
    }
}