class Application {
    constructor() {
        this.container = document.getElementById('gallery-wrapper');
        if (!this.container) { console.error("Gallery wrapper (#gallery-wrapper) not found!"); return; }
        
        this.canvasContainer = document.getElementById('canvas-container');
        if (!this.canvasContainer) { console.error("Canvas container (#canvas-container) not found!"); return; }

        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(60, this.canvasContainer.clientWidth / this.canvasContainer.clientHeight, 0.1, 20000);
        this.renderer = new THREE.WebGLRenderer({
            antialias: true,
            alpha: true,
            logarithmicDepthBuffer: true 
        });
        
        this.ui = new UIController(this.container);
        this.map = new MapController(this.scene);
        this.interaction = new InteractionController(this.camera, this.renderer.domElement, this.map, this.ui);

        this._setupScene();
        this._setupEventListeners();
        
        this.ui.log('Architecture simulation ready.');
        
        this.animate();
        this._initializeApp();
    }

    _initializeApp() {
        // 【Lazy Load】不再一次性加载所有配置
        this.ui.log('Lazy load enabled. Fetching initial view...');
        
        // 触发第一次加载
        setTimeout(() => {
            this.interaction.onViewChange();
        }, 500);

        this._checkUrlForLocation();
    }

    _setupScene() {
        this.camera.position.set(0, 0, 2000);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.setClearColor(0x000000, 0);
        this.canvasContainer.appendChild(this.renderer.domElement);
        this.map.create();
        this.onWindowResize();
    }

    _setupEventListeners() {
        const fullscreenBtn = document.getElementById('fullscreen-btn');
        if(fullscreenBtn) { fullscreenBtn.addEventListener('click', () => this.toggleFullscreen()); }
        window.addEventListener('resize', () => this.onWindowResize());
        this.ui.onSearch((bitmapId) => { if (this.interaction) { this.interaction.focusOnBitmap(bitmapId); } });
    }

    animate() {
        requestAnimationFrame(() => this.animate());

        // 保留您原始的GIF更新逻辑
        if (this.map && this.map.avatarGroup) {
            this.map.avatarGroup.children.forEach(avatar => {
                if (avatar.userData.isGif) {
                    avatar.material.map.needsUpdate = true;
                }
            });
        }

        if (this.interaction) { this.interaction.update(); }
        this.renderer.render(this.scene, this.camera);
    }
    
    onWindowResize() {
        const canvasWindow = document.getElementById('canvas-window');
        if(!canvasWindow) return;
        const w = canvasWindow.clientWidth;
        const h = canvasWindow.clientHeight;
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(w, h);
    }
    
    toggleFullscreen() {
        const galleryElement = this.container;
        if (!galleryElement) return;
        if (!document.fullscreenElement) {
            galleryElement.requestFullscreen().catch(err => {
                this.ui.log(`Error enabling full-screen: ${err.message}`);
            });
            galleryElement.classList.add('fullscreen-active');
        } else {
            document.exitFullscreen();
            galleryElement.classList.remove('fullscreen-active');
        }
    }

    _checkUrlForLocation() {
        const urlParams = new URLSearchParams(window.location.search);
        const location = urlParams.get('location');
        if (location) {
            this.ui.log(`Found location in URL: ${location}. Focusing...`);
            setTimeout(() => {
                if (this.interaction) {
                    this.interaction.focusOnBitmap(location);
                }
            }, 500);
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new Application();
});