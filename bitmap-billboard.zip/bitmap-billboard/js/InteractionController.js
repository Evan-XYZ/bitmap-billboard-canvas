class InteractionController {
    constructor(camera, domElement, mapController, uiController) {
        this.camera = camera;
        this.domElement = domElement;
        this.map = mapController;
        this.ui = uiController;
        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();
        this.hoveredAvatar = null;

        // --- Lazy Load Properties ---
        this.isFetching = false;
        this.fetchTimeout = null;
        
        this._setupControls();
        this._setupEventListeners();
    }
    
    _setupControls() {
        this.controls = new THREE.OrbitControls(this.camera, this.domElement);
        // 保留您原始的、被验证为有效的配置
        this.controls.enableRotate = false;
        this.controls.enablePan = true;
        this.controls.mouseButtons = { LEFT: THREE.MOUSE.PAN, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: null };
        this.controls.enableZoom = true;
        this.controls.zoomSpeed = 4.0;
        this.controls.minDistance = 80;
        this.controls.maxDistance = 20000;
        this.controls.dampingFactor = 0.1;
        this.controls.enableDamping = true;

        // 【Lazy Load 核心】添加 'end' 事件监听，用于在用户停止操作时加载数据
        this.controls.addEventListener('end', () => this.onViewChange());
    }
    
    _setupEventListeners() {
        // 【UI修复】完全保留您原始的、有效的事件监听器设置
        this.domElement.addEventListener('mousedown', () => { this.domElement.style.cursor = 'grabbing'; });
        this.domElement.addEventListener('mouseup', () => { this.domElement.style.cursor = 'grab'; });
        this.domElement.addEventListener('mouseleave', () => { this.ui.hideHoverLabel(); this.map.highlightFrame.visible = false; });
        this.domElement.addEventListener('mousemove', (e) => this.onMouseMove(e));
        this.domElement.addEventListener('click', (e) => this.onClick(e));
    }

    // --- Lazy Load 功能函数 ---
    onViewChange() {
        clearTimeout(this.fetchTimeout);
        this.fetchTimeout = setTimeout(() => {
            if (this.isFetching) return;
            const viewBounds = this.getCurrentViewBounds();
            if (!viewBounds) return;
            this.fetchAvatarsInRange(viewBounds.minId, viewBounds.maxId);
        }, 250);
    }

    getCurrentViewBounds() {
        const plane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0);
        const corners = [ new THREE.Vector2(-1, 1), new THREE.Vector2(1, 1), new THREE.Vector2(-1, -1), new THREE.Vector2(1, -1) ];
        let minX, maxX, minY, maxY;
        corners.forEach((corner, i) => {
            this.raycaster.setFromCamera(corner, this.camera);
            const pos = new THREE.Vector3();
            this.raycaster.ray.intersectPlane(plane, pos);
            if (i === 0) { minX = maxX = pos.x; minY = maxY = pos.y; } else { minX = Math.min(minX, pos.x); maxX = Math.max(maxX, pos.x); minY = Math.min(minY, pos.y); maxY = Math.max(maxY, pos.y); }
        });
        const topLeftIndex = this.getParcelIndexFromPosition(minX, maxY);
        const bottomRightIndex = this.getParcelIndexFromPosition(maxX, minY);
        return { minId: Math.max(1, topLeftIndex + 1), maxId: Math.min(this.map.totalParcels, bottomRightIndex + 1) };
    }

    getParcelIndexFromPosition(x, y) {
        const { parcelSize, gap, parcelsPerRow, totalParcels } = this.map;
        const totalWidth = (parcelsPerRow - 1) * (parcelSize + gap);
        const totalHeight = ((totalParcels / parcelsPerRow) - 1) * (parcelSize + gap);
        const col = Math.round((x + totalWidth / 2) / (parcelSize + gap));
        const row = Math.round((-y + totalHeight / 2) / (parcelSize + gap));
        return Math.max(0, Math.min(totalParcels - 1, row * parcelsPerRow + col));
    }

    async fetchAvatarsInRange(minId, maxId) {
        if (minId > maxId || minId > this.map.totalParcels) return;
        this.isFetching = true;
        this.ui.log(`Fetching avatars from ${minId} to ${maxId}...`);
        try {
            const apiUrl = `${window.wpGalleryData.apiUrl}?min_id=${minId}&max_id=${maxId}`;
            const response = await fetch(apiUrl);
            if (!response.ok) throw new Error(`API request failed: ${response.status}`);
            const configs = await response.json();
            if (configs.length > 0) {
                this.ui.log(`Loaded ${configs.length} new avatars.`);
                this.map.loadAvatars(configs);
            } else {
                 this.ui.log(`No new avatars found in range.`);
            }
        } catch (error) {
            this.ui.log(`Error fetching avatars: ${error.message}`);
            console.error(error);
        } finally {
            this.isFetching = false;
        }
    }
    
    // --- 原始交互函数 (保持不变) ---
    onClick(e) {
        const canvasWindow = document.getElementById('canvas-container');
        if(!canvasWindow) return;
        const rect = canvasWindow.getBoundingClientRect();
        this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        this.raycaster.setFromCamera(this.mouse, this.camera);
        const intersects = this.raycaster.intersectObjects(this.map.avatarGroup.children, false);
        if (intersects.length > 0) {
            const firstIntersected = intersects[0].object;
            if (firstIntersected.userData.isAvatar && firstIntersected.userData.contentUrl) {
                this.ui.showModal(firstIntersected.userData.contentUrl, firstIntersected.userData.iframeWidth, firstIntersected.userData.iframeHeight);
            }
        }
    }

    update() {
        if(this.controls) this.controls.update();

        // 为高亮边框添加呼吸效果
        if (this.map.highlightFrame.visible) {
            // 使用 sin 函数创建一个平滑的 0.98 到 1.02 的缩放循环
            const pulse = 1 + Math.sin(Date.now() * 0.006) * 0.02;
            this.map.highlightFrame.scale.set(pulse, pulse, 1);
        }
    }

    onMouseMove(e) {
        const canvasWindow = document.getElementById('canvas-container');
        if(!canvasWindow) return;
        const rect = canvasWindow.getBoundingClientRect();
        this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        this.raycaster.setFromCamera(this.mouse, this.camera);
        const objectsToTest = [this.map.instancedMesh, ...this.map.avatarGroup.children];
        const intersects = this.raycaster.intersectObjects(objectsToTest, false);
        
        if (this.hoveredAvatar) { 
            this.hoveredAvatar.scale.set(1, 1, 1); 
            this.hoveredAvatar = null; 
        }

        let didIntersect = false;
        if (intersects.length > 0) {
            const firstIntersect = intersects[0];
            const intersectedObject = firstIntersect.object;
            let pos, labelText;

            if (intersectedObject.userData.isAvatar) {
                this.hoveredAvatar = intersectedObject;
                this.hoveredAvatar.scale.set(1.1, 1.1, 1.1);
                pos = intersectedObject.position;
                labelText = intersectedObject.userData.bitmapId;
                didIntersect = true;
            } else if (intersectedObject === this.map.instancedMesh && firstIntersect.instanceId !== undefined) {
                const index = firstIntersect.instanceId;
                pos = this.map.getParcelPosition(index);
                labelText = `${index + 1}.bitmap`;
                didIntersect = true;
            }

            if (didIntersect) {
                this.ui.showHoverLabel(labelText, e);
                this.map.highlightFrame.position.set(pos.x, pos.y, 0.1);
                this.map.highlightFrame.visible = true;
            }
        } 
        
        if (!didIntersect) { 
            this.ui.hideHoverLabel(); 
            this.map.highlightFrame.visible = false; 
        }
    }

    focusOnBitmap(bitmapId) {
        const id = parseInt(bitmapId.toString().replace('.bitmap', ''));
        if (isNaN(id) || id < 1 || id > this.map.totalParcels) { 
            this.ui.log(`Error: Invalid Bitmap ID "${bitmapId}"`); 
            return; 
        }
        
        const newUrl = `${window.location.protocol}//${window.location.host}${window.location.pathname}?location=${id}.bitmap`;
        window.history.pushState({path: newUrl}, '', newUrl);
        
        const index = id - 1;
        const targetPosition = this.map.getParcelPosition(index);
        const zoomDistance = 150;
        
        gsap.to(this.camera.position, { 
            x: targetPosition.x, 
            y: targetPosition.y, 
            z: zoomDistance, 
            duration: 1.5, 
            ease: "power2.out" 
        });

        gsap.to(this.controls.target, { 
            x: targetPosition.x, 
            y: targetPosition.y, 
            z: 0, 
            duration: 1.5, 
            ease: "power2.out",
            onComplete: () => {
                this.ui.log('Focus animation complete. Fetching data for new view...');
                // 动画完成后，手动调用一次视图更新函数
                this.onViewChange();
            }
        });

        this.map.highlightFrame.position.set(targetPosition.x, targetPosition.y, 0.1);
        this.map.highlightFrame.visible = true;
        this.ui.log(`Focused on: ${id}.bitmap`);
    }
}