<?php /** Template Name: Canvas App Only */ ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>body, html { margin: 0; padding: 0; overflow: hidden; background-color: #000; }</style>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <noscript><strong>JavaScript is required to view this content.</strong></noscript>
    <?php
    echo '<div id="canvas-window" style="width: 100vw; height: 100vh; position: relative; background: #000; overflow: hidden;"><div id="canvas-container" style="width: 100%; height: 100%; position: relative; cursor: grab;"></div><div id="debug" style="position: absolute; top: 10px; left: 10px; color: #777; font-family: monospace; font-size: 10px; z-index: 1001; pointer-events: none;"></div><div id="ui-controls" style="position: absolute; top: 10px; right: 10px; z-index: 1001; display: flex; gap: 10px; align-items: center;"><div id="search-container" style="display: flex; background: #333; border: 1px solid #555; border-radius: 3px; padding: 2px;"><input type="text" id="search-input" placeholder="e.g., 454545" style="background: transparent; border: none; color: #fff; padding: 4px 8px; outline: none;"><button id="search-btn" style="background: #f7931a; color: #111; border: none; cursor: pointer; padding: 4px 10px; border-radius: 2px; font-weight: bold;">Find</button></div><button id="fullscreen-btn" style="padding: 5px 10px; cursor: pointer; background: #333; color: #fff; border: 1px solid #555; border-radius: 3px;">Fullscreen</button></div></div><div class="modal-overlay" id="modal-overlay" style="display: flex; position: fixed; z-index: 2000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.8); backdrop-filter: blur(8px); align-items: center; justify-content: center; opacity: 0; visibility: hidden; transition: opacity 0.4s ease, visibility 0s 0.4s;"><div class="modal-content" style="background: #2c2c2c; padding: 0; border-radius: 12px; width: 90%; height: 85%; max-width: 1200px; overflow: hidden; position: relative; display: flex; flex-direction: column; transform: scale(0.95); transition: transform 0.4s ease;"><button class="close-btn" title="Close" style="position: absolute; top: 15px; right: 15px; font-size: 30px; color: #aaa; cursor: pointer; background: none; border: none; z-index: 10; padding: 5px; line-height: 1;">×</button><div id="modal-body" style="padding: 20px; width: 100%; height: 100%; box-sizing: border-box; flex-grow: 1; display: flex;"><iframe style="width:100%;height:100%;border:none;border-radius:4px;"></iframe></div></div></div>';
    ?>
    <?php wp_footer(); ?>
</body>
</html>