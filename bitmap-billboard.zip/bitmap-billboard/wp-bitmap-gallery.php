<?php
/**
 * Plugin Name:       Bitmap 3D Gallery
 * Description:       Displays an interactive million-pixel Three.js scene via the [bitmap_gallery] shortcode.
 * Version:           7.2 (Internationalization Update)
 * Author:            EvanXYZ
 */

if (!defined('ABSPATH')) exit;

define('BITMAP_GALLERY_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BITMAP_GALLERY_PLUGIN_PATH', plugin_dir_path(__FILE__));

// 1. Create database table on plugin activation (includes 'operator' field)
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'bitmap_configs';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        bitmap_id mediumint(9) NOT NULL,
        image_url varchar(255) DEFAULT '' NOT NULL,
        iframe_url varchar(255) DEFAULT '' NOT NULL,
        iframe_width smallint(5) DEFAULT 0 NOT NULL,
        iframe_height smallint(5) DEFAULT 0 NOT NULL,
        operator varchar(255) DEFAULT '' NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY bitmap_id (bitmap_id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
});

// 2. Add admin menu
add_action('admin_menu', function() {
    add_menu_page('Bitmap Gallery Config', 'Bitmap Config', 'manage_options', 'bitmap-gallery-config', 'bitmap_gallery_admin_page_html', 'dashicons-screenoptions', 20);
});

// 3. Render the admin configuration page (Now in English and displays Operator)
function bitmap_gallery_admin_page_html() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'bitmap_configs';

    // Handle form submission for saving config
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_bitmap_config']) && check_admin_referer('bitmap_config_nonce')) {
        $bitmap_id = intval($_POST['bitmap_id']);
        $image_url = esc_url_raw($_POST['image_url']);
        $iframe_url = esc_url_raw($_POST['iframe_url']);
        $iframe_width = intval($_POST['iframe_width']);
        $iframe_height = intval($_POST['iframe_height']);
        
        if ($bitmap_id > 0) {
            // Note: This admin form does not set the 'operator'. That is handled by the user-facing form.
            $wpdb->replace($table_name, [
                'bitmap_id' => $bitmap_id, 
                'image_url' => $image_url, 
                'iframe_url' => $iframe_url, 
                'iframe_width' => $iframe_width, 
                'iframe_height' => $iframe_height
            ], ['%d', '%s', '%s', '%d', '%d']);
            echo '<div class="notice notice-success is-dismissible"><p>Configuration saved!</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>Error: Bitmap ID must be a number greater than 0.</p></div>';
        }
    }

    // Handle deletion
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id']) && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'bitmap_delete_nonce')) {
        $id_to_delete = intval($_GET['id']);
        $wpdb->delete($table_name, ['id' => $id_to_delete], ['%d']);
        echo '<div class="notice notice-success is-dismissible"><p>Configuration deleted!</p></div>';
    }

    // Fetch all configs to display in the table
    $configs = $wpdb->get_results("SELECT * FROM $table_name ORDER BY bitmap_id ASC");
    ?>
    <div class="wrap">
        <h1>Bitmap Plot Configuration</h1>
        <p>Configure the avatar and IFrame pop-up link for specific plots here.</p>

        <h2>Add / Update Configuration</h2>
        <form method="post">
            <?php wp_nonce_field('bitmap_config_nonce'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><label for="bitmap_id">Bitmap ID (1-1,000,000)</label></th>
                    <td><input type="number" id="bitmap_id" name="bitmap_id" required min="1" max="1000000" /> (e.g., 454545)</td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="image_url">Avatar Image URL</label></th>
                    <td><input type="url" id="image_url" name="image_url" class="large-text" placeholder="https://example.com/image.png" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="iframe_url">Pop-up IFrame URL</label></th>
                    <td><input type="url" id="iframe_url" name="iframe_url" class="large-text" placeholder="https://example.com/page.html" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="iframe_width">Pop-up Width (px)</label></th>
                    <td><input type="number" id="iframe_width" name="iframe_width" placeholder="Leave blank for default (90%)" /> (e.g., 800)</td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="iframe_height">Pop-up Height (px)</label></th>
                    <td><input type="number" id="iframe_height" name="iframe_height" placeholder="Leave blank for default (85%)" /> (e.g., 600)</td>
                </tr>
            </table>
            <?php submit_button('Save Configuration', 'primary', 'submit_bitmap_config'); ?>
        </form>

        <h2>Configured Plots</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Bitmap ID</th>
                    <th>Avatar Image URL</th>
                    <th>IFrame URL</th>
                    <th>Operator</th>
                    <th>Pop-up Size (WxH)</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($configs)): ?>
                    <tr><td colspan="6">No configurations yet.</td></tr>
                <?php else: foreach ($configs as $config): ?>
                    <tr>
                        <td><?php echo esc_html($config->bitmap_id); ?></td>
                        <td><a href="<?php echo esc_url($config->image_url); ?>" target="_blank"><?php echo esc_html(wp_basename($config->image_url)); ?></a></td>
                        <td><a href="<?php echo esc_url($config->iframe_url); ?>" target="_blank"><?php echo esc_html($config->iframe_url); ?></a></td>
                        <td><?php echo esc_html($config->operator); ?></td>
                        <td><?php echo (int)$config->iframe_width > 0 ? (int)$config->iframe_width . 'px' : 'Default'; ?> x <?php echo (int)$config->iframe_height > 0 ? (int)$config->iframe_height . 'px' : 'Default'; ?></td>
                        <td><a href="<?php echo wp_nonce_url(admin_url('admin.php?page=bitmap-gallery-config&action=delete&id=' . $config->id), 'bitmap_delete_nonce'); ?>" style="color: #a00;" onclick="return confirm('Are you sure you want to delete this configuration?')">Delete</a></td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}


// 4. Create public REST API endpoint
add_action('rest_api_init', function() {
    register_rest_route('bitmap-gallery/v1', '/configs', [
        'methods' => 'GET',
        'callback' => 'bitmap_gallery_get_configs_in_range',
        'permission_callback' => '__return_true',
    ]);
});

function bitmap_gallery_get_configs_in_range(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'bitmap_configs';
    $min_id = $request->get_param('min_id');
    $max_id = $request->get_param('max_id');

    // Only proceed if a valid range is provided
    $min_id = isset($min_id) ? intval($min_id) : 0;
    $max_id = isset($max_id) ? intval($max_id) : 0;
    
    // The query returns data for the lazy load. It does not need the 'operator' field for the frontend.
    $query = "SELECT bitmap_id, image_url, iframe_url, iframe_width, iframe_height FROM $table_name";

    if ($min_id > 0 && $max_id > 0 && $max_id >= $min_id) {
        $query .= $wpdb->prepare(" WHERE bitmap_id BETWEEN %d AND %d", $min_id, $max_id);
    } else {
        // Return an empty array if the range is invalid to prevent loading the whole table
        $response = new WP_REST_Response([], 200);
        return $response;
    }
    
    $results = $wpdb->get_results($query);
    $response = new WP_REST_Response($results ?: [], 200);
    
    // Set headers to prevent caching of API responses
    $response->set_headers(['Cache-Control' => 'no-cache, must-revalidate, max-age=0', 'Pragma' => 'no-cache', 'Expires' => 'Wed, 11 Jan 1984 05:00:00 GMT']);
    
    return $response;
}


// 5. Register the shortcode and its output
add_shortcode('bitmap_gallery', function() {
    add_action('wp_footer', 'bitmap_gallery_enqueue_scripts');
    $html_and_css = <<<HTML
    <style>
        .bitmap-gallery-wrapper { position: relative; width: 1200px; height: 800px; max-width: 100%; margin: 20px auto; }
        .label { position: absolute; background: rgba(0,0,0,0.75); color: #fff; padding: 4px 8px; border: 1px solid #f0f0f0; border-radius: 4px; font-size: 14px; pointer-events: none; white-space: nowrap; z-index: 3000; transform: translate(-50%, 20px); }
        .modal-overlay { display: flex; position: fixed; z-index: 2000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.8); backdrop-filter: blur(8px); align-items: center; justify-content: center; opacity: 0; visibility: hidden; transition: opacity 0.4s ease, visibility 0s 0.4s; }
        .fullscreen-active .modal-overlay { position: absolute; }
        .modal-overlay.active { opacity: 1 !important; visibility: visible !important; transition: opacity 0.4s ease; }
        .modal-overlay.active .modal-content { transform: scale(1); }
        .modal-content { --modal-width: 90%; --modal-height: 85%; --modal-max-width: 1200px; width: var(--modal-width); height: var(--modal-height); max-width: var(--modal-max-width); }
    </style>
    <div class="bitmap-gallery-wrapper" id="gallery-wrapper">
        <div id="canvas-window" style="width: 100%; height: 100%; border: 2px solid #333; background: #000; overflow: hidden;">
            <div id="canvas-container" style="width: 100%; height: 100%; position: relative; cursor: grab;"></div>
        </div>
        <div id="debug" style="position: absolute; top: 10px; left: 10px; color: #777; font-family: monospace; font-size: 10px; z-index: 1001; pointer-events: none;"></div>
        <div id="ui-controls" style="position: absolute; top: 10px; right: 10px; z-index: 1001; display: flex; gap: 10px; align-items: center;">
            <div id="search-container" style="display: flex; background: #333; border: 1px solid #555; border-radius: 3px; padding: 2px;">
                <input type="text" id="search-input" placeholder="e.g., 454545" style="background: transparent; border: none; color: #fff; padding: 4px 8px; outline: none;">
                <button id="search-btn" style="background: #f7931a; color: #111; border: none; cursor: pointer; padding: 4px 10px; border-radius: 2px; font-weight: bold;">Find</button>
            </div>
            <button id="fullscreen-btn" style="padding: 5px 10px; cursor: pointer; background: #333; color: #fff; border: 1px solid #555; border-radius: 3px;">Fullscreen</button>
        </div>
        <div class="modal-overlay" id="modal-overlay"><div class="modal-content" style="background: #2c2c2c; padding: 0; border-radius: 12px; overflow: hidden; position: relative; display: flex; flex-direction: column; transform: scale(0.95); transition: transform 0.4s ease;"><button class="close-btn" title="Close" style="position: absolute; top: 15px; right: 15px; font-size: 30px; color: #aaa; cursor: pointer; background: none; border: none; z-index: 10; padding: 5px; line-height: 1;">×</button><div id="modal-body" style="padding: 20px; width: 100%; height: 100%; box-sizing: border-box; flex-grow: 1; display: flex;"><iframe style="width:100%;height:100%;border:none;border-radius:4px;"></iframe></div></div></div>
    </div>
HTML;
    return $html_and_css;
});

// 6. Enqueue all necessary scripts
function bitmap_gallery_enqueue_scripts() {
    $version = '7.2'; // Update version number
    wp_enqueue_script('threejs', BITMAP_GALLERY_PLUGIN_URL . 'js/lib/three.min.js', [], '128.0', true);
    wp_enqueue_script('threejs-orbit-controls', BITMAP_GALLERY_PLUGIN_URL . 'js/lib/OrbitControls.js', ['threejs'], '128.0', true);
    wp_enqueue_script('gsap', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.9.1/gsap.min.js', [], '3.9.1', true);
    wp_enqueue_script('bitmap-gallery-ui', BITMAP_GALLERY_PLUGIN_URL . 'js/UIController.js', [], $version, true);
    wp_enqueue_script('bitmap-gallery-map', BITMAP_GALLERY_PLUGIN_URL . 'js/MapController.js', ['threejs'], $version, true);
    wp_enqueue_script('bitmap-gallery-interaction', BITMAP_GALLERY_PLUGIN_URL . 'js/InteractionController.js', ['threejs', 'gsap', 'threejs-orbit-controls'], $version, true);
    
    $main_dependencies = ['bitmap-gallery-ui', 'bitmap-gallery-map', 'bitmap-gallery-interaction'];
    wp_enqueue_script('bitmap-gallery-main', BITMAP_GALLERY_PLUGIN_URL . 'js/main.js', $main_dependencies, $version, true);
    
    // Pass the API URL to the main script
    wp_localize_script('bitmap-gallery-main', 'wpGalleryData', ['apiUrl' => esc_url_raw(rest_url('bitmap-gallery/v1/configs'))]);
}

// 7. Add Cloudflare compatibility attribute to scripts
add_filter('script_loader_tag', function($tag, $handle) {
    $scripts_to_defer = ['threejs', 'gsap', 'threejs-orbit-controls', 'bitmap-gallery-ui', 'bitmap-gallery-map', 'bitmap-gallery-interaction', 'bitmap-gallery-main'];
    if (in_array($handle, $scripts_to_defer)) {
        return str_replace(' src', ' data-cfasync="false" src', $tag);
    }
    return $tag;
}, 10, 2);